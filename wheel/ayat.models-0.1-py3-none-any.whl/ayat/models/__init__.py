from ayat import app
from ayat import db
from ayat.models.users import *
from ayat.models.assessments import *
from ayat.models.programs import *
from ayat.models.recitations import *
from ayat.models.scheduling import *


def setup_db():
    """Method used to build a database"""
    print("Building DB...")
    db.create_all()


def teardown_db():
    """Method used to destroy a database"""
    print("Destroying DB...")
    db.session.remove()
    db.drop_all()
    db.session.bind.dispose()

